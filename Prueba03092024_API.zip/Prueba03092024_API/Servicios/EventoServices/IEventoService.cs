﻿using Prueba03092024_API.Modelos;

namespace Prueba03092024_API.Servicios.EventoServices
{
    public interface IEventoService
    {
        List<Evento> eventos();
        Evento postEvento(Evento evento);


    }
}
