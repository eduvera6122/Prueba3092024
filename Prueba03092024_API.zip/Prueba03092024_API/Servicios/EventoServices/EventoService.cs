﻿using Prueba03092024_API.Modelos;

namespace Prueba03092024_API.Servicios.EventoServices
{
    public class EventoService : IEventoService
    {
        public List<Evento> eventos()
        {
            return Data.eventos;
        }

        public Evento postEvento(Evento evento)
        {
            evento.Id= Data.eventos.Count + 1;
            Data.eventos.Add(evento);

            return evento;
        }
    }
}
