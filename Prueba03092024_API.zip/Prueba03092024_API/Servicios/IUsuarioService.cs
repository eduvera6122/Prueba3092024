﻿using Microsoft.AspNetCore.Identity;
using Prueba03092024_API.Modelos;

namespace Prueba03092024_API.Servicios
{
    public interface IUsuarioService
    {

        Usuario login(Login login);







    }
}
