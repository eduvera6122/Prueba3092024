﻿using Prueba03092024_API.Modelos;

namespace Prueba03092024_API.Servicios.ActividadServices
{
    public class ActividadService : IActividadService
    {
        public List<Actividad> GetActividadList()
        {
            return Data.actividades;
        }

        public Actividad postActividad(Actividad actividad)
        {
           actividad.Id = Data.actividades.Count + 1;
           Data.actividades.Add(actividad);
            return actividad;

        }
    }
}
