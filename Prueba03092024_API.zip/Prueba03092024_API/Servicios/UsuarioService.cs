﻿using Prueba03092024_API.Modelos;

namespace Prueba03092024_API.Servicios
{
    public class UsuarioService : IUsuarioService
    {
        public Usuario login(Login login)
        {
            Usuario usuario = Data.usuarios.FirstOrDefault(u => u.Name == login.Username && u.Password == login.Password);

            return usuario;

        }
    }
}
