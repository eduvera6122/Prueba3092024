﻿using Prueba03092024_API.Modelos;

namespace Prueba03092024_API
{
    public class Data
    {

        public static List<Usuario> usuarios = new List<Usuario>
        {
            new Usuario(1 , "Eduardo" , "eduromero@gmail.com" ,"123")
        };
        public static List<Evento> eventos = new List<Evento>
        {
            new Evento(1, "Fiesta" ,"Cumpleaños de un niño",DateTime.Now),
        };
        public static List<Actividad> actividades = new List<Actividad>
        {
            new Actividad (1 , "Bailar" , "Bailar" ,"1 hora")
        };

    }
}
