﻿using Microsoft.AspNetCore.Mvc;
using Prueba03092024_API.Modelos;
using Prueba03092024_API.Servicios.EventoServices;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Prueba03092024_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EventoController : ControllerBase
    {

        private readonly IEventoService _service;


        public EventoController(IEventoService service)
        {
            _service = service;
        }



        // GET: api/<EventoController>
        [HttpGet]
        public IActionResult Get()
        {
            return Ok(_service.eventos());
        }

       

        // POST api/<EventoController>
        [HttpPost]
        public IActionResult Post([FromBody] Evento evento)
        {
            return Ok(_service.postEvento(evento));
        }

      
    }
}
