﻿using Microsoft.AspNetCore.Mvc;
using Prueba03092024_API.Modelos;
using Prueba03092024_API.Servicios;


namespace Prueba03092024_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsuarioController : ControllerBase
    {
        private readonly IUsuarioService _service;


      public UsuarioController (IUsuarioService service)
        {
            _service = service;
        }



        [HttpPost]
        public IActionResult Post([FromBody] Login login)
        {
            Usuario usuario = _service.login(login);

            if (usuario == null)
            {
                return NotFound();
            }

            return Ok(usuario);
        }

    }
}
