﻿using Microsoft.AspNetCore.Mvc;
using Prueba03092024_API.Modelos;
using Prueba03092024_API.Servicios.ActividadServices;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Prueba03092024_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ActividadController : ControllerBase
    {
        private readonly IActividadService _service;


        public ActividadController(IActividadService service)
        {
            _service = service;
        }

        [HttpGet]
        public IActionResult Get()
        {
            return Ok(_service.GetActividadList());
        }

      
        [HttpPost]
        public IActionResult Post([FromBody] Actividad  actividad)
        {
            if(actividad == null)
            {
                return BadRequest();
            }

            return Ok(_service.postActividad(actividad));
        }

       
    }
}
