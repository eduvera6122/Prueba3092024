﻿namespace Prueba03092024_API.Modelos
{
    public class Usuario
    {

        public int Id { get; set; }

        public string Name { get; set; }
        public string Email { get; set; }

        public string Password { get; set; }


        public Usuario(int id, string name, string email, string password)
        {
            Id = id;
            Name = name;
            Email = email;
            Password = password;
        }



    }

    public class Login
    {
        public string Username { get; set; }
        public string Password { get; set; }
    
    }


}
