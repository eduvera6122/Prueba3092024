﻿namespace Prueba03092024_API.Modelos
{
    public class Actividad
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public string Type { get; set; }


        public string Tiempo { get; set; }


        public Actividad(int id , string name , string type , string tiempo)
        {
            Id = id;
            Name = name;
            Type = type;
            Tiempo = tiempo;

        }



    }
}
