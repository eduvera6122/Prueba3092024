﻿namespace Prueba03092024_API.Modelos
{
    public class Evento
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public string Descripcion { get; set; }

        public DateTime FechaEvento { get; set; }


        public Evento (int id , string name , string descripcion , DateTime fechaEvento)
        {
            Id = id;
            Name = name;
            Descripcion = descripcion;
            FechaEvento = fechaEvento;
        }



    }
}
