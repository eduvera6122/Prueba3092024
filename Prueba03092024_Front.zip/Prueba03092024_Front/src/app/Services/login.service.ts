import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Actividad, Evento, Login } from '../login.interface';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  constructor(private http : HttpClient) { }

  login(login :Login){
    return this.http.post('https://localhost:7159/api/Usuario', login);
  }

  obtenerEventos():Observable<Evento[]>{
    return this.http.get<Evento[]>('https://localhost:7159/api/Evento');
  }

  registrarEvento(evento : Evento){
    return this.http.post('https://localhost:7159/api/Evento', evento);
  }

  obtenerActividades():Observable<Actividad[]>{
    return this.http.get<Actividad[]>('https://localhost:7159/api/Actividad');
  }


  registrarActividad(actividad : Actividad){ 
    return this.http.post('https://localhost:7159/api/Actividad', actividad); 
  }

}
