export interface Login{
    username: string;
    password : string;
}

export interface Evento{
   id : number; 
   name : string;
   descripcion : string;
   fechaEvento : Date;

}  
export interface Actividad{
    id : number;
    name : string;
    type : string;
    tiempo : string;
}
