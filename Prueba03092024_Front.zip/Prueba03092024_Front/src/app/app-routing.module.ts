import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { EventosComponent } from './eventos/eventos.component';
import { LoginComponent } from './login/login.component';
import { RegistrarEventoComponent } from './registrar-evento/registrar-evento.component';
import { ActividadesComponent } from './actividades/actividades.component';
import { RegistrarActividadComponent } from './registrar-actividad/registrar-actividad.component';

const routes: Routes = [
  { path: 'home', component: LoginComponent },
  { path: 'eventos', component: EventosComponent },
  {path : "nuevoEvento" , component : RegistrarEventoComponent},
  {path : "nuevaActividad" , component : RegistrarActividadComponent},
  {path : "listarActividades" , component : ActividadesComponent},
  { path: '', redirectTo: '/home', pathMatch: 'full' } // Redirige al Home por defecto
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
