import { Component, OnInit } from '@angular/core';
import { Actividad } from '../login.interface';
import { LoginService } from '../Services/login.service';

@Component({
  selector: 'app-actividades',
  templateUrl: './actividades.component.html',
  styleUrls: ['./actividades.component.css']
})
export class ActividadesComponent implements OnInit {


  actividades : Actividad[] = [];

  constructor (private loginService : LoginService) { 
   
  }

  ngOnInit(): void {
    this.loginService.obtenerActividades().subscribe(data =>{
      console.log(data);
      this.actividades = data;
      console.log(this.actividades + "data");
    })
  }

}
