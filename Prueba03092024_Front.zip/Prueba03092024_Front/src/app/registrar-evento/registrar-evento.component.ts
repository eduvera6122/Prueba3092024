import { Component } from '@angular/core';
import { LoginService } from '../Services/login.service';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Evento } from '../login.interface';

@Component({
  selector: 'app-registrar-evento',
  templateUrl: './registrar-evento.component.html',
  styleUrls: ['./registrar-evento.component.css']
})
export class RegistrarEventoComponent {

eventoForm: FormGroup;
evennto : Evento = {
  id: 0,
  name: '',
  descripcion: '',
  fechaEvento: new Date()
};




constructor(private formBuilderService: FormBuilder , private authService: LoginService ,private router : Router ) {
    this.eventoForm = this.formBuilderService.group({
        name: ['', [Validators.required]],
        descripcion: ['', [Validators.required]],
        fechaEvento: ['', [Validators.required]]
    });
}

ngOnInit(): void {
    let form = document.querySelector('form') as HTMLFormElement;
    form.addEventListener('submit', (submitEvent: SubmitEvent) => {
        if (!form.checkValidity()) {
            submitEvent.preventDefault();
            submitEvent.stopPropagation();
        }

        form.classList.add('was-validated');
    });
}

    registrarEvento(){

      this.evennto.id = 0;
      this.evennto.name = this.eventoForm.get('name')?.value;
      this.evennto.descripcion = this.eventoForm.get('descripcion')?.value;
      this.evennto.fechaEvento = this.eventoForm.get('fechaEvento')?.value;
    
      this.authService.registrarEvento(this.evennto).subscribe(data =>{
        console.log(data);
      })
    
      this.router.navigate(['/eventos']);
    }


}

