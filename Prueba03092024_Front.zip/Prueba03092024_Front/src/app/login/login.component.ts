import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Login } from '../login.interface';
import { LoginService } from '../Services/login.service';
import { Router, RouterModule } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit{

  loginForm: FormGroup;
  login : Login = {
    username: '',
    password: ''
  }
  constructor(private formBuilderService: FormBuilder , private authService: LoginService ,private router : Router ) {
      this.loginForm = this.formBuilderService.group({
          username: ['', [Validators.required]],
          password: ['', [Validators.required, validatePassword]],
          phoneNumber: ['', [Validators.required]],
      });
  }

  ngOnInit(): void {
      let form = document.querySelector('form') as HTMLFormElement;
      form.addEventListener('submit', (submitEvent: SubmitEvent) => {
          if (!form.checkValidity()) {
              submitEvent.preventDefault();
              submitEvent.stopPropagation();
          }

          form.classList.add('was-validated');
      });
  }

  loginUser(): void {
     this.login.username = this.loginForm.get('username')?.value;
     this.login.password = this.loginForm.get('password')?.value;
  

    this.authService.login(this.login).subscribe(data =>{
      console.log(data);
      this.router.navigate(['/eventos']);
    }
    )


  }





}

export function validatePassword(
  formControl: AbstractControl
): { [key: string]: any } | null {
  if (formControl.value && formControl.value.length < 8) {
      return { passwordInvalid: true };
  }
  return null;
}



