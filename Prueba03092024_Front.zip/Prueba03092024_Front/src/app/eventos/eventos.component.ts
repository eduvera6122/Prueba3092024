import { Component, OnInit } from '@angular/core';
import { Evento } from '../login.interface';
import { LoginService } from '../Services/login.service';

@Component({
  selector: 'app-eventos',
  templateUrl: './eventos.component.html',
  styleUrls: ['./eventos.component.css']
})
export class EventosComponent implements OnInit {

  eventos : Evento[] = [];

  constructor (private loginService : LoginService) { 
   
  }

  ngOnInit(): void {
    this.loginService.obtenerEventos().subscribe(data =>{
      console.log(data);
      this.eventos = data;
      console.log(this.eventos + "data");
    })
  }




}
