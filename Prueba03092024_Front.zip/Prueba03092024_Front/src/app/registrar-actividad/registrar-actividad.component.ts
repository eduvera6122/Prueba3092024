import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Actividad } from '../login.interface';
import { LoginService } from '../Services/login.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-registrar-actividad',
  templateUrl: './registrar-actividad.component.html',
  styleUrls: ['./registrar-actividad.component.css']
})
export class RegistrarActividadComponent implements OnInit {


  actividades: string[] = ['Correr', 'Leer', 'Cocinar', 'Viajar'];
  times: string[] = ['10 min', '20 min', '30 min', '1 hour', '2 hours'];

  actividadForm: FormGroup;
  actividad : Actividad = {
    id: 0,
    name: '',
    type: '',
    tiempo : ''
  };
  
  
  
  
  constructor(private formBuilderService: FormBuilder , private authService: LoginService ,private router : Router ) {
      this.actividadForm = this.formBuilderService.group({
          name: ['', [Validators.required]],
          type: ['', [Validators.required]],
          tiempo: ['', [Validators.required]]
      });
  }
  
  ngOnInit(): void {
      let form = document.querySelector('form') as HTMLFormElement;
      form.addEventListener('submit', (submitEvent: SubmitEvent) => {
          if (!form.checkValidity()) {
              submitEvent.preventDefault();
              submitEvent.stopPropagation();
          }
  
          form.classList.add('was-validated');
      });
  }
  
      registrarActividad(){

        this.actividad.id = 0;
        this.actividad.name = this.actividadForm.get('name')?.value;
        this.actividad.type = this.actividadForm.get('type')?.value;
        this.actividad.tiempo = this.actividadForm.get('tiempo')?.value;
      
        this.authService.registrarActividad(this.actividad).subscribe(response => {
            console.log(response);
            this.router.navigate(['/listarActividades']);
        })
       
      }
  
  
}
